"""ESP (RFC 4303) in tunnel mode: AES-256-CBC + HMAC-SHA-256-128."""
import hmac
import os
import struct
from hashlib import sha256

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from .errors import AuthenticationError
from .packet import IPv4, PROTO_ESP, PROTO_IPIP

ICV_LEN, IV_LEN, BLOCK = 16, 16, 16


def _icv(key: bytes, data: bytes) -> bytes:
    return hmac.new(key, data, sha256).digest()[:ICV_LEN]


def encapsulate(inner: bytes, sa) -> bytes:
    """Encrypt the whole inner IP packet and wrap it in a new outer IP header."""
    seq = sa.next_seq(len(inner))
    pad_len = (-(len(inner) + 2)) % BLOCK
    plain = inner + bytes(range(1, pad_len + 1)) + bytes([pad_len, PROTO_IPIP])
    iv = os.urandom(IV_LEN)
    enc = Cipher(algorithms.AES(sa.enc_key), modes.CBC(iv)).encryptor()
    ct = enc.update(plain) + enc.finalize()
    head = struct.pack("!II", sa.spi, seq)
    body = head + iv + ct
    return IPv4(sa.src, sa.dst, PROTO_ESP, body + _icv(sa.auth_key, body)).pack()


def decapsulate(raw: bytes, sad) -> bytes:
    """Verify, replay-check and decrypt; return the inner IP packet."""
    outer = IPv4.parse(raw)
    spi, seq = struct.unpack("!II", outer.payload[:8])
    sa = sad.lookup(outer.dst, "esp", spi)
    body, icv = outer.payload[:-ICV_LEN], outer.payload[-ICV_LEN:]
    if not hmac.compare_digest(icv, _icv(sa.auth_key, body)):
        raise AuthenticationError("ESP ICV mismatch")
    sa.check_replay(seq)
    sa.replay.update(seq)
    iv, ct = body[8:8 + IV_LEN], body[8 + IV_LEN:]
    dec = Cipher(algorithms.AES(sa.enc_key), modes.CBC(iv)).decryptor()
    plain = dec.update(ct) + dec.finalize()
    pad_len, next_hdr = plain[-2], plain[-1]
    if next_hdr != PROTO_IPIP or plain[-2 - pad_len:-2] != bytes(range(1, pad_len + 1)):
        raise AuthenticationError("ESP trailer invalid")
    return plain[:-2 - pad_len]
