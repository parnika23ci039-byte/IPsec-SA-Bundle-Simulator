"""Security Association, replay window and the SAD."""
import ipaddress
import os
from dataclasses import dataclass, field

from .errors import LifetimeExpired, NoSAError, ReplayError


class ReplayWindow:
    """RFC 4303 style sliding anti-replay window (32-bit sequence numbers)."""

    def __init__(self, size: int = 64):
        self.size, self.top, self.bitmap = size, 0, 0

    def check(self, seq: int) -> bool:
        if seq == 0:
            return False
        if seq > self.top:
            return True
        diff = self.top - seq
        return diff < self.size and not (self.bitmap >> diff) & 1

    def update(self, seq: int) -> None:
        mask = (1 << self.size) - 1
        if seq > self.top:
            shift = seq - self.top
            self.bitmap = ((self.bitmap << shift) | 1) & mask if shift < self.size else 1
            self.top = seq
        else:
            self.bitmap |= 1 << (self.top - seq)


@dataclass
class SA:
    spi: int
    proto: str                 # "esp" or "ah"
    mode: str                  # "tunnel" or "transport"
    src: str                   # tunnel/peer endpoints (gateway addresses)
    dst: str
    auth_key: bytes
    enc_key: bytes = b""       # empty for AH
    max_bytes: int = 4 * 2**30
    seq: int = 0
    bytes_done: int = 0
    packets: int = 0
    replay: ReplayWindow = field(default_factory=ReplayWindow)

    def next_seq(self, nbytes: int) -> int:
        if self.seq >= 0xFFFFFFFF or self.bytes_done + nbytes > self.max_bytes:
            raise LifetimeExpired(f"SA 0x{self.spi:x} must be rekeyed")
        self.seq += 1
        self.bytes_done += nbytes
        self.packets += 1
        return self.seq

    def check_replay(self, seq: int) -> None:
        if not self.replay.check(seq):
            raise ReplayError(f"SA 0x{self.spi:x}: seq {seq} replayed or too old")

    def __str__(self):
        return (f"SPI=0x{self.spi:04x} {self.proto.upper():3} {self.mode:9} "
                f"{self.src} -> {self.dst}  seq={self.seq} pkts={self.packets}")


class SAD:
    """Security Association Database, indexed by (dst IP, protocol, SPI)."""

    def __init__(self):
        self._db = {}

    def add(self, sa: SA):
        self._db[(sa.dst, sa.proto, sa.spi)] = sa

    def lookup(self, dst: str, proto: str, spi: int) -> SA:
        try:
            return self._db[(dst, proto, spi)]
        except KeyError:
            raise NoSAError(f"no {proto.upper()} SA for dst={dst} spi=0x{spi:x}")

    def all(self):
        return list(self._db.values())


@dataclass
class Policy:
    """One SPD entry: traffic local_net -> remote_net is PROTECTed by `out_sas`
    (applied in list order, e.g. [ESP tunnel, AH transport])."""
    local_net: ipaddress.IPv4Network
    remote_net: ipaddress.IPv4Network
    out_sas: list

    def matches_out(self, src, dst):
        return (ipaddress.ip_address(src) in self.local_net and
                ipaddress.ip_address(dst) in self.remote_net)

    def matches_in(self, src, dst):
        return (ipaddress.ip_address(src) in self.remote_net and
                ipaddress.ip_address(dst) in self.local_net)


def new_key(n=32) -> bytes:
    return os.urandom(n)
