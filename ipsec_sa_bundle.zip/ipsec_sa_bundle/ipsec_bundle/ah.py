"""AH (RFC 4302) in transport mode applied over an ESP packet.

The ICV covers the outer IP header (mutable fields TOS, flags/frag, TTL and
checksum zeroed), the AH header and everything after it.
"""
import hmac
import struct
from hashlib import sha256

from .errors import AuthenticationError
from .packet import IPv4, PROTO_AH

ICV_LEN = 16
AH_LEN = 12 + ICV_LEN          # next hdr, len, rsv, SPI, seq, ICV


def _icv(key: bytes, ip: IPv4, ah_zero: bytes, rest: bytes) -> bytes:
    hdr = IPv4(ip.src, ip.dst, PROTO_AH, ah_zero + rest,
               ttl=0, tos=0, ident=ip.ident, flags_frag=0).pack()
    hdr = hdr[:10] + b"\x00\x00" + hdr[12:]            # zero checksum
    return hmac.new(key, hdr + ah_zero + rest, sha256).digest()[:ICV_LEN]


def protect(esp_packet: bytes, sa) -> bytes:
    ip = IPv4.parse(esp_packet)
    seq = sa.next_seq(len(esp_packet))
    ah_zero = struct.pack("!BBHII", ip.proto, AH_LEN // 4 - 2, 0, sa.spi, seq) + bytes(ICV_LEN)
    icv = _icv(sa.auth_key, ip, ah_zero, ip.payload)
    ah = ah_zero[:12] + icv
    return IPv4(ip.src, ip.dst, PROTO_AH, ah + ip.payload,
                ttl=ip.ttl, tos=ip.tos, ident=ip.ident, flags_frag=ip.flags_frag).pack()


def verify(raw: bytes, sad) -> bytes:
    """Verify AH and return the packet with the AH header removed."""
    ip = IPv4.parse(raw)
    next_hdr, _plen, _rsv, spi, seq = struct.unpack("!BBHII", ip.payload[:12])
    sa = sad.lookup(ip.dst, "ah", spi)
    icv, rest = ip.payload[12:AH_LEN], ip.payload[AH_LEN:]
    ah_zero = ip.payload[:12] + bytes(ICV_LEN)
    if not hmac.compare_digest(icv, _icv(sa.auth_key, ip, ah_zero, rest)):
        raise AuthenticationError("AH ICV mismatch")
    sa.check_replay(seq)
    sa.replay.update(seq)
    return IPv4(ip.src, ip.dst, next_hdr, rest, ttl=ip.ttl, tos=ip.tos,
                ident=ip.ident, flags_frag=ip.flags_frag).pack()
