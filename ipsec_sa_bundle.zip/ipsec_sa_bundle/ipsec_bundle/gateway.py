"""Security gateway: SPD lookup, SA bundle processing, and a tiny 'IKE'."""
import ipaddress

from . import ah, esp
from .errors import PolicyError
from .packet import IPv4, PROTO_AH, PROTO_ESP
from .sa import SA, SAD, Policy, new_key


class Gateway:
    def __init__(self, name: str, addr: str, lan: str):
        self.name, self.addr = name, addr
        self.lan = ipaddress.ip_network(lan)
        self.sad, self.spd = SAD(), []
        self.stats = {"protected": 0, "accepted": 0, "dropped": 0}

    # ---- outbound: SPD -> apply SAs in order ---------------------------------
    def protect(self, inner: bytes) -> bytes:
        ip = IPv4.parse(inner)
        for pol in self.spd:
            if pol.matches_out(ip.src, ip.dst):
                pkt = inner
                for sa in pol.out_sas:
                    pkt = esp.encapsulate(pkt, sa) if sa.proto == "esp" else ah.protect(pkt, sa)
                self.stats["protected"] += 1
                return pkt
        raise PolicyError(f"{self.name}: no PROTECT policy for {ip.src}->{ip.dst} (DISCARD)")

    # ---- inbound: peel AH, then ESP, then check SPD --------------------------
    def unprotect(self, wire: bytes) -> bytes:
        try:
            pkt = wire
            while True:
                proto = IPv4.parse(pkt).proto
                if proto == PROTO_AH:
                    pkt = ah.verify(pkt, self.sad)
                elif proto == PROTO_ESP:
                    inner = esp.decapsulate(pkt, self.sad)
                    break
                else:
                    raise PolicyError(f"{self.name}: unprotected protocol {proto} discarded")
            ip = IPv4.parse(inner)
            if not any(p.matches_in(ip.src, ip.dst) for p in self.spd):
                raise PolicyError(f"{self.name}: inner {ip.src}->{ip.dst} not allowed by SPD")
            self.stats["accepted"] += 1
            return inner
        except Exception:
            self.stats["dropped"] += 1
            raise


def establish(a: Gateway, b: Gateway, bundle=("esp", "ah")):
    """Stand-in for IKEv2: derive fresh keys and install SAs + SPD on both gateways.

    SPIs follow the case-study table (A->B: 0x1001/0x2001, B->A: 0x1002/0x2002).
    """
    spi_base = {"esp": 0x1000, "ah": 0x2000}
    mode = {"esp": "tunnel", "ah": "transport"}

    def make(src, dst, proto, n):
        return SA(spi=spi_base[proto] + n, proto=proto, mode=mode[proto], src=src.addr,
                  dst=dst.addr, auth_key=new_key(32),
                  enc_key=new_key(32) if proto == "esp" else b"")

    a_out = [make(a, b, p, 1) for p in bundle]
    b_out = [make(b, a, p, 2) for p in bundle]
    for sa in a_out + b_out:
        a.sad.add(sa) if sa.dst == a.addr else None
        b.sad.add(sa) if sa.dst == b.addr else None
    a.spd.append(Policy(a.lan, b.lan, a_out))
    b.spd.append(Policy(b.lan, a.lan, b_out))
    return a_out, b_out
