"""Minimal IPv4 packet build/parse (no options, no fragmentation)."""
import socket
import struct
from dataclasses import dataclass

PROTO_ICMP, PROTO_IPIP, PROTO_UDP, PROTO_ESP, PROTO_AH = 1, 4, 17, 50, 51


def checksum(data: bytes) -> int:
    if len(data) % 2:
        data += b"\x00"
    s = sum(struct.unpack("!%dH" % (len(data) // 2), data))
    while s >> 16:
        s = (s & 0xFFFF) + (s >> 16)
    return ~s & 0xFFFF


@dataclass
class IPv4:
    src: str
    dst: str
    proto: int
    payload: bytes
    ttl: int = 64
    tos: int = 0
    ident: int = 0
    flags_frag: int = 0

    def pack(self) -> bytes:
        total = 20 + len(self.payload)
        args = (0x45, self.tos, total, self.ident, self.flags_frag, self.ttl,
                self.proto, 0, socket.inet_aton(self.src), socket.inet_aton(self.dst))
        hdr = struct.pack("!BBHHHBBH4s4s", *args)
        csum = checksum(hdr)
        hdr = hdr[:10] + struct.pack("!H", csum) + hdr[12:]
        return hdr + self.payload

    @classmethod
    def parse(cls, raw: bytes) -> "IPv4":
        if len(raw) < 20 or raw[0] >> 4 != 4:
            raise ValueError("not an IPv4 packet")
        ihl = (raw[0] & 0x0F) * 4
        tos, total, ident, ff, ttl, proto, _c, src, dst = struct.unpack(
            "!xBHHHBBH4s4s", raw[:20])
        return cls(socket.inet_ntoa(src), socket.inet_ntoa(dst), proto,
                   raw[ihl:total], ttl, tos, ident, ff)


def udp_packet(src, dst, sport, dport, data: bytes, ident=1) -> bytes:
    """Build an IPv4/UDP packet (UDP checksum left 0, legal for IPv4)."""
    udp = struct.pack("!HHHH", sport, dport, 8 + len(data), 0) + data
    return IPv4(src, dst, PROTO_UDP, udp, ident=ident).pack()
