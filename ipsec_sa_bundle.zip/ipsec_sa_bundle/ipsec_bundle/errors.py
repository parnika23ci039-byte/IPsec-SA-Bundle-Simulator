class IPsecError(Exception):
    """Base class for all simulation errors."""

class AuthenticationError(IPsecError):
    """ICV verification failed (AH or ESP)."""

class ReplayError(IPsecError):
    """Sequence number already seen or outside the replay window."""

class NoSAError(IPsecError):
    """No matching Security Association in the SAD."""

class PolicyError(IPsecError):
    """Packet rejected by the Security Policy Database."""

class LifetimeExpired(IPsecError):
    """SA exceeded its byte or sequence lifetime and must be rekeyed."""
