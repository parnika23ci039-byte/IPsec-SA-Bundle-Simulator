# Securing Inter-Office Communication with Multiple Security Associations

Working simulation of the case study: two offices joined over the Internet need
**authentication + confidentiality**. A single SA cannot give both with
outer-header protection, so the gateways apply an **SA bundle**:

| SA | Protocol / mode | Purpose |
|----|-----------------|---------|
| Inner | ESP, tunnel (AES-256-CBC + HMAC-SHA-256-128) | Encrypts the original packet, hides internal IPs |
| Outer | AH, transport (HMAC-SHA-256-128) | Authenticates the whole packet incl. the outer IP header |

Encrypt first, authenticate last: the receiver verifies AH **before** decrypting,
so forged packets are dropped cheaply. 4 SAs total (SPIs 0x1001/0x2001 A->B, 0x1002/0x2002 B->A).

```
Host A -- GW-A (203.0.113.1) ==[ IP | AH | ESP(encrypted inner packet) ]== GW-B (198.51.100.1) -- Host B
 192.168.10.0/24                        Internet                                   192.168.20.0/24
```

## Layout
```
ipsec_bundle/
  packet.py   IPv4 build/parse, checksum
  sa.py       SA, replay window, SAD, SPD policy
  esp.py      ESP tunnel encapsulate/decapsulate
  ah.py       AH transport protect/verify (mutable fields zeroed in ICV)
  gateway.py  Gateway (SPD lookup, bundle processing) + establish() (IKE stand-in)
demo.py       Scripted scenario with attacks
tests/        15 unit tests
```

## Run
```
pip install cryptography
python3 demo.py
python3 -m unittest discover -s tests -t . -v
```

## What the demo/tests prove
| Property | Result |
|----------|--------|
| Round trip both directions | Original packet delivered intact |
| Confidentiality | Payload and inner 192.168.x.x addresses absent from the wire |
| Integrity | Flipped ciphertext bit dropped (AH ICV mismatch) |
| Outer-header spoofing | Dropped with ESP+AH; **accepted by ESP-only** (why the bundle exists) |
| Anti-replay | Duplicate packet dropped; out-of-order within window accepted |
| Policy | Non-matching traffic discarded; inbound inner packet checked against SPD |
| Lifetime | SA raises `LifetimeExpired` at byte/sequence limit (rekey needed) |
| Overhead | About 95 bytes for a 57-byte packet (outer IP 20, AH 28, ESP 8+16+16+pad/trailer) |

## Limitations
- Educational simulation, not production IPsec: no IKEv2 (keys come from `os.urandom` in `establish()`), no fragmentation/PMTU, no ESN, IPv4 only.
- AH cannot traverse NAT; this design assumes gateways with public addresses.
- Modern deployments usually use a single ESP SA with AES-GCM; the bundle is the classic textbook answer to "one SA is not enough".
- For a real lab, translate to Linux `ip xfrm` or strongSwan on two VMs and capture with Wireshark.
