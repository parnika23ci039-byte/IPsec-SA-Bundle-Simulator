"""Demo: two offices, ESP-tunnel + AH-transport SA bundle."""
import struct
from ipsec_bundle import Gateway, establish, AuthenticationError, ReplayError, PolicyError
from ipsec_bundle.packet import IPv4, udp_packet, checksum


def banner(t): print(f"\n{'=' * 8} {t} {'=' * 8}")


def describe(wire: bytes) -> str:
    """What an eavesdropper on the Internet link can see."""
    ip = IPv4.parse(wire)
    out = [f"IP {ip.src} -> {ip.dst} proto={ip.proto} ({len(wire)} bytes)"]
    if ip.proto == 51:
        nh, _l, _r, spi, seq = struct.unpack("!BBHII", ip.payload[:12])
        out.append(f"AH  spi=0x{spi:04x} seq={seq} icv={ip.payload[12:28].hex()[:16]}...")
        e = ip.payload[28:]
        espspi, eseq = struct.unpack("!II", e[:8])
        out.append(f"ESP spi=0x{espspi:04x} seq={eseq} payload=<{len(e) - 8} encrypted bytes>")
    return "\n    ".join(out)


gw_a = Gateway("GW-A", "203.0.113.1", "192.168.10.0/24")
gw_b = Gateway("GW-B", "198.51.100.1", "192.168.20.0/24")
a_out, b_out = establish(gw_a, gw_b)

banner("SAs installed (4 total)")
for sa in a_out + b_out:
    print(" ", sa)

secret = b"Q3 salary table: CONFIDENTIAL"
inner = udp_packet("192.168.10.5", "192.168.20.9", 5000, 5001, secret)

banner("1. Host A -> Host B")
wire = gw_a.protect(inner)
print("  original :", len(inner), "bytes  192.168.10.5 -> 192.168.20.9")
print("  on wire  :", describe(wire))
print("  overhead :", len(wire) - len(inner), "bytes")
assert gw_b.unprotect(wire) == inner
print("  GW-B delivered the original packet intact: OK")

banner("2. Confidentiality (eavesdropper)")
print("  plaintext visible on wire? ", secret in wire)
print("  inner IPs visible on wire? ", b"\xc0\xa8\x0a\x05" in wire or b"\xc0\xa8\x14\x09" in wire)

banner("3. Tampering with the encrypted payload")
bad = bytearray(gw_a.protect(inner)); bad[-5] ^= 1
try: gw_b.unprotect(bytes(bad))
except AuthenticationError as e: print("  dropped ->", e)

banner("4. Spoofing the OUTER source IP (needs AH)")
spoof = bytearray(gw_a.protect(inner)); spoof[12:16] = bytes([6, 6, 6, 6])
spoof[10:12] = b"\x00\x00"
spoof[10:12] = struct.pack("!H", checksum(bytes(spoof[:20])))
try: gw_b.unprotect(bytes(spoof))
except AuthenticationError as e: print("  bundle (ESP+AH) dropped ->", e)

es_a = Gateway("E-A", "203.0.113.1", "192.168.10.0/24")
es_b = Gateway("E-B", "198.51.100.1", "192.168.20.0/24")
establish(es_a, es_b, bundle=("esp",))
w = bytearray(es_a.protect(inner)); w[12:16] = bytes([6, 6, 6, 6])
w[10:12] = b"\x00\x00"
w[10:12] = struct.pack("!H", checksum(bytes(w[:20])))
print("  ESP-only accepted the spoofed outer header:", es_b.unprotect(bytes(w)) == inner)

banner("5. Replay attack")
w1 = gw_a.protect(inner)
gw_b.unprotect(w1)
try: gw_b.unprotect(w1)
except ReplayError as e: print("  dropped ->", e)

banner("6. Traffic outside the policy")
try: gw_a.protect(udp_packet("192.168.10.5", "8.8.8.8", 1, 2, b"x"))
except PolicyError as e: print("  discarded ->", e)

banner("7. Reverse direction B -> A")
reply = udp_packet("192.168.20.9", "192.168.10.5", 5001, 5000, b"ack")
assert gw_a.unprotect(gw_b.protect(reply)) == reply
print("  OK")

banner("Gateway stats")
print("  GW-A", gw_a.stats); print("  GW-B", gw_b.stats)
