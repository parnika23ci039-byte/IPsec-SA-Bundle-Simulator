import unittest
from ipsec_bundle import (Gateway, establish, AuthenticationError, ReplayError,
                          PolicyError, LifetimeExpired)
from ipsec_bundle.packet import IPv4, udp_packet, checksum
from ipsec_bundle.sa import ReplayWindow


def pair(bundle=("esp", "ah")):
    a = Gateway("A", "203.0.113.1", "192.168.10.0/24")
    b = Gateway("B", "198.51.100.1", "192.168.20.0/24")
    out = establish(a, b, bundle)
    return a, b, out


def pkt(data=b"hello world", src="192.168.10.5", dst="192.168.20.9"):
    return udp_packet(src, dst, 1000, 2000, data)


def respoof(raw: bytearray) -> bytes:
    raw[12:16] = bytes([6, 6, 6, 6])
    raw[10:12] = b"\x00\x00"
    raw[10:12] = checksum(bytes(raw[:20])).to_bytes(2, "big")
    return bytes(raw)


class BundleTests(unittest.TestCase):
    def test_roundtrip_both_directions(self):
        a, b, _ = pair()
        p, q = pkt(), pkt(src="192.168.20.9", dst="192.168.10.5")
        self.assertEqual(b.unprotect(a.protect(p)), p)
        self.assertEqual(a.unprotect(b.protect(q)), q)

    def test_four_sas_with_expected_spis(self):
        _, _, (ao, bo) = pair()
        self.assertEqual([s.spi for s in ao + bo], [0x1001, 0x2001, 0x1002, 0x2002])

    def test_wire_order_is_ah_then_esp(self):
        a, _, _ = pair()
        w = a.protect(pkt())
        ip = IPv4.parse(w)
        self.assertEqual(ip.proto, 51)               # AH outermost
        self.assertEqual(ip.payload[0], 50)          # next header = ESP
        self.assertEqual((ip.src, ip.dst), ("203.0.113.1", "198.51.100.1"))

    def test_confidentiality(self):
        a, _, _ = pair()
        w = a.protect(pkt(b"TOP-SECRET-PAYLOAD"))
        self.assertNotIn(b"TOP-SECRET-PAYLOAD", w)
        self.assertNotIn(bytes([192, 168, 10, 5]), w)
        self.assertNotIn(bytes([192, 168, 20, 9]), w)

    def test_ciphertext_tamper_detected_by_ah(self):
        a, b, _ = pair()
        w = bytearray(a.protect(pkt())); w[-3] ^= 0x01
        with self.assertRaisesRegex(AuthenticationError, "AH"):
            b.unprotect(bytes(w))

    def test_outer_header_spoof_detected_with_bundle(self):
        a, b, _ = pair()
        with self.assertRaises(AuthenticationError):
            b.unprotect(respoof(bytearray(a.protect(pkt()))))

    def test_outer_header_spoof_missed_by_esp_only(self):
        a, b, _ = pair(("esp",))
        p = pkt()
        self.assertEqual(b.unprotect(respoof(bytearray(a.protect(p)))), p)

    def test_replay_rejected(self):
        a, b, _ = pair()
        w = a.protect(pkt()); b.unprotect(w)
        with self.assertRaises(ReplayError):
            b.unprotect(w)

    def test_out_of_order_within_window_accepted(self):
        a, b, _ = pair()
        ws = [a.protect(pkt()) for _ in range(5)]
        for w in (ws[4], ws[2], ws[3], ws[0]):
            b.unprotect(w)

    def test_wrong_key_rejected(self):
        a, b, _ = pair()
        _, other_b, _ = pair()
        with self.assertRaises(Exception):
            other_b.unprotect(a.protect(pkt()))

    def test_policy_discards_unlisted_traffic(self):
        a, _, _ = pair()
        with self.assertRaises(PolicyError):
            a.protect(pkt(dst="8.8.8.8"))

    def test_inbound_spd_check_on_inner_packet(self):
        a, b, _ = pair()
        a.spd[0].local_net = __import__("ipaddress").ip_network("0.0.0.0/0")
        a.spd[0].remote_net = a.spd[0].local_net
        with self.assertRaises(PolicyError):               # wrong inner src for B
            b.unprotect(a.protect(pkt(src="10.9.9.9")))

    def test_sequence_numbers_increase(self):
        a, _, (ao, _) = pair()
        for _ in range(3):
            a.protect(pkt())
        self.assertEqual([s.seq for s in ao], [3, 3])

    def test_lifetime_expiry(self):
        a, _, (ao, _) = pair()
        ao[0].max_bytes = 10
        with self.assertRaises(LifetimeExpired):
            a.protect(pkt())

    def test_replay_window_unit(self):
        w = ReplayWindow(64)
        for s in (1, 2, 70):
            self.assertTrue(w.check(s)); w.update(s)
        self.assertFalse(w.check(2))     # duplicate
        self.assertFalse(w.check(5))     # older than window (70-5 >= 64)
        self.assertTrue(w.check(69))     # inside window, unseen
        self.assertFalse(w.check(0))


if __name__ == "__main__":
    unittest.main()
